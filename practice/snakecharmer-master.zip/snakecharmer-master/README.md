snakecharmer
============

A toolkit for working with python
