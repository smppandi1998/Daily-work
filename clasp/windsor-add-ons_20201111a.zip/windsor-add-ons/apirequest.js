/*##############################################################################
#
# Module:  apirequest.gs
#
# Function:
#	Google Spreadsheet Add-on script that handles API requests.
#
# Version:
#	V2.01	Mon Jun 15 2020 17:02:00 sveluthambi	Edit level 1
#
# Copyright notice:
#	This file copyright (C) 2020 by
#
#		MCCI Corporation
#		3520 Krums Corners Road
#		Ithaca, NY  14850
#
#	An unpublished work.  All rights reserved.
#
#	This file is proprietary information, and may not be disclosed or
#	copied without the prior permission of MCCI Corporation
#
# Author:
#	Sivaprakash Veluthambi, MCCI Corporation	June 2020
#
# Revision History:
#   2.01  Mon Jun 15 2020 17:02:00  sveluthambi
#	Module created.
#
##############################################################################*/

/*

Name:	sendRequest

Function:
	Google App Script init function which loads the Customized Templates

Definition:
	function sendRequest(url, methodtype, token=null)

Description:
	This function frames API requests using the parameters passed to this
	function and fetches result for that request.

Returns:
	Result of processed request/URL.

*/

function sendRequest(url, methodtype, token=null)
	{
	var ui = SpreadsheetApp.getUi();
	var url = url;
	var options = {
		'method': methodtype,
		'	muteHttpExceptions': true,
	}

	if(token) {
		options.headers = {'Authorization': 'Bearer ' + token};
	}

	try {
		var response = UrlFetchApp.fetch(url, options);

		if (response.getResponseCode() == 200) {
			var json = response.getContentText();
			var data = JSON.parse(json);
			return data;
			}
		else {
			errorMsg("Can't Establish Connection"
				+ "\n"
				+ "Error code: "
				+ response.getResponseCode()
				+ "\n"
				+ response.getContentText()
			);
			logMsg("Can't Establish Connection"
				+ "\n"
				+ "Error code: "
				+ response.getResponseCode()
				+ "\n"
				+ response.getContentText()
			);
			return null;
			}
		}
	catch (err) {
		errorMsg("Can't processing url request");
		logMsg(err);
		return null;
		}
	}

