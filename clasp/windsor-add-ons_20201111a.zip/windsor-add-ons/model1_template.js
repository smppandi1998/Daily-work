/*##############################################################################
#
# Module:  model1_template.gs
#
# Function:
#	Google Spreadsheet Add-on that populates the data from server
#	into spreadsheet in Model 1 template format.
#
# Version:
#	V2.02	Mon Aug 03 2020 12:25:00 revathy	Edit level 2
#
# Copyright notice:
#	This file copyright (C) 2020 by
#
#		MCCI Corporation
#		3520 Krums Corners Road
#		Ithaca, NY  14850
#
#	An unpublished work.  All rights reserved.
#
#	This file is proprietary information, and may not be disclosed or
#	copied without the prior permission of MCCI Corporation
#
# Author:
#	Prabhu Srinivasan, MCCI Corporation	June 2020
#
# Revision History:
#   V2.01  Mon Jun 15 2020 17:02:00  prabhus
#	Module created.
#   V2.02  Mon Aug 03 2020 12:26:00  revathyg
#	Common prefix and reference column position change for color coding
#
##############################################################################*/

/*
Name:	weradiate_DT_init_model1template

Function:
	Google App Script Init function to start the Model1 template filling receive params

Definition:
	function weradiate_DT_init_model1template(weradiate_DT_hClient)

Description:
	This function initializes the required parameters and calls up the
	respective functions that loads the user selected Template Model in the
	spreadsheet.

Returns:
	Nothing.
*/

function weradiate_DT_init_model1template(weradiate_DT_hClient, ss)
	{
	var spreadsheet = ss;
	var weradiate_DT_allPiles = {};
	var weradiate_DT_allLocations={};
	var length = 0;

	/*get from date via function*/
	startdate = weradiate_DT_getFromDate(weradiate_DT_hClient);
	tFromDate = weradiate_DT_formatDate(startdate);

	/*get end date via function*/
	enddate = weradiate_DT_getToDate(weradiate_DT_hClient);
	tToDate = weradiate_DT_formatDate(enddate);

	weradiate_DT_sites = weradiate_DT_getAllSites(weradiate_DT_hClient)
	for(var site in weradiate_DT_sites)
		{
		weradiate_DT_allPiles[site] = [];
		weradiate_DT_allLocations[site] = {};
		weradiate_DT_piles =weradiate_DT_getAllPilesOfaSite(weradiate_DT_hClient,weradiate_DT_sites[site]);

		for( var pile_index = 0;pile_index < weradiate_DT_piles.length; pile_index++)
			{
			weradiate_DT_allPiles[site][pile_index]=weradiate_DT_piles[pile_index];
			}

		for(var pile in weradiate_DT_piles)
			{
			weradiate_DT_allLocations[site][pile] = [];
			weradiate_DT_locations = weradiate_DT_getAllLocationOfaPile(weradiate_DT_hClient, weradiate_DT_sites[site], weradiate_DT_piles[pile])
			weradiate_DT_allLocations[site][pile].push(weradiate_DT_locations);
			for( var location_index = 0;location_index < weradiate_DT_locations.length; location_index++)
				{
				weradiate_DT_allLocations[site][pile][location_index]= weradiate_DT_locations[location_index];
				}
			length = weradiate_DT_locations.length+length;
			}
		}

	weradiate_DT_Fillcontents_Model1(
		weradiate_DT_hClient,
		spreadsheet,
		length,
		tFromDate,
		tToDate,
		weradiate_DT_sites,
		weradiate_DT_allPiles,
		weradiate_DT_allLocations
		);
	}

/*
Name:	weradiate_DT_Fillcontents_Model1

Function:
	Google App Script Init function to start the Model1 template filling receive params

Definition:
	function weradiate_DT_Fillcontents_Model1(
		weradiate_DT_hClient,
		spreadsheet,
		length,
		tFromDate,
		tToDate,
		weradiate_DT_sites,
		weradiate_DT_allPiles,
		weradiate_DT_allLocations
		)

Description:
	This function fill the contents w.r.t. the Template Model 1 in the
	spreadsheet using the Parameters it receives.

Returns:
	Nothing.
*/
/**
 * Function to fill the contents in the sheet
 *
 * @param hClient - Handle of the client
 * @param spreadsheet - Current active sheet
 * @param length - Length of all locations in site
 * @param tFromDate - From date selected by user
 * @param tToDate - To date selected by user
 * @param sites - all sites
 * @param allPiles - all Piles in the site
 * @param allLocations - all locations in the site
 */
function weradiate_DT_Fillcontents_Model1(
	weradiate_DT_hClient,
	spreadsheet,
	length,
	tFromDate,
	tToDate,
	weradiate_DT_sites,
	weradiate_DT_allPiles,
	weradiate_DT_allLocations
	)
	{

	/*for 2D array*/
	const fnGet2D = function(v) {
		return  [v[0], v[1]] ;
		};
	/*for 1D array*/
	const fnGet1D = function(v) {
		return  v[2] ;
		};

	var client_name = weradiate_DT_hClient.client;
	var title = client_name + ' Template (Model 1)';
	var title_cell = 'E3';
	var count = 0;
	var day_heading_cell = 'B5';
	var date_heading_cell = 'C5';
	var data_heading_cell = 'D5';
	for (var siteIndex = 0; siteIndex  < weradiate_DT_sites.length; siteIndex++)
		{
		for (var pileIndex = 0 ; pileIndex < weradiate_DT_allPiles[siteIndex].length; pileIndex++)
			{
			for (var locationIndex = 0; locationIndex < weradiate_DT_allLocations[siteIndex][pileIndex].length; locationIndex++)
				{
				var workingSheet = spreadsheet.getSheets()[count];
				workingSheet.clear();
				var sheet_name = workingSheet.setName(weradiate_DT_sites[siteIndex] + ' | ' + weradiate_DT_allPiles[siteIndex][pileIndex] +
						 ' | '+ weradiate_DT_allLocations[siteIndex][pileIndex][locationIndex]);

				weradiate_DT_TitleCard(workingSheet,title,title_cell);
				workingSheet.getRange(day_heading_cell).setValue("Day").setHorizontalAlignment('center')
				.setBorder(true, true, true, true, true, true, '#000000'
					, SpreadsheetApp.BorderStyle.SOLID);
				workingSheet.getRange(date_heading_cell).setValue("Date").setHorizontalAlignment('center')
				.setBorder(true, true, true, true, true, true, '#000000'
					, SpreadsheetApp.BorderStyle.SOLID);
				dateFilling_start_row = 6;
				dateFilling_start_column = 2;
				dateFilling_last_column = 2;
				HeaderData = weradiate_DT_generate_data(tFromDate, tToDate);
				workingSheet.getRange(dateFilling_start_row, dateFilling_start_column, HeaderData.length, dateFilling_last_column)
				.setHorizontalAlignment('center').setValues(HeaderData.map(fnGet2D))
				.setBorder(true, true, true, true, true, true, '#000000', SpreadsheetApp.BorderStyle.SOLID);

				date_heading = HeaderData.map(fnGet1D);
				data_column = 4;
				weradiate_DT_column_datafill(
					weradiate_DT_hClient,
					tFromDate,
					tToDate,
					weradiate_DT_sites[siteIndex],
					weradiate_DT_allPiles[siteIndex][pileIndex],
					weradiate_DT_allLocations[siteIndex][pileIndex][locationIndex],
					workingSheet,
					data_column,
					date_heading
					);
				weradiate_DT_plot_chart_model1(date_heading.length,workingSheet);
				spreadsheet.insertSheet();
				count++;
				}
			}
		}
	}

/*
Name:	weradiate_DT_plot_chart_model1

Function:
	Google App Script function to provide Chart representation for Model 1

Definition:
	function weradiate_DT_plot_chart_model1(length, spreadsheet)

Description:
	This function fill the contents w.r.t. the Template Model 1 in the
	spreadsheet using the Parameters it receives.

Returns:
	Nothing.
*/
/*
 * Chart Plot Function
 * @param  length - length of all locations
 * @param  spreadsheet - passing active spreadsheet
 */
function weradiate_DT_plot_chart_model1(length, spreadsheet)
	{

	xrange_start_row = 5;
	xrange_start_column = 3;
	yrange_column = 5;
	var xrange1 = spreadsheet.getRange(xrange_start_row, xrange_start_column).getA1Notation();
	var yrange2 = spreadsheet.getRange(xrange_start_row+length, yrange_column).getA1Notation();
	var chart_flag = 1;

	Logger.log("Chart values::::::::::::" , spreadsheet.getRange(xrange1+':'+yrange2).getValues());
	range = xrange1+':'+yrange2;

	reference_range_row = 5;
	reference_column = 4;
	spreadsheet.insertColumns(reference_column);
	var ref1 = spreadsheet.getRange(reference_range_row, reference_column).getA1Notation();
	var ref2 = spreadsheet.getRange(reference_range_row + length, reference_column).getA1Notation();
	reference_range = ref1+':'+ref2;
	Logger.log(reference_range);
	var refLineValue = weradiate_DT_getRefLineCount(weradiate_DT_hClient);
	spreadsheet.getRange(reference_range).setValue(refLineValue);
	spreadsheet.hideColumns(reference_column);
	chart_position = 7;

	weradiate_DT_createEmbeddedLineChart_(
		spreadsheet,
		spreadsheet,
		chart_flag,
		range,
		chart_position,
		//reference_range
		);
	}

