/*##############################################################################
#
# Module:  DEC_template.gs
#
# Function:
#	Google Spreadsheet Add-on that populates the data from server
#	into spreadsheet in DEC Report template format.
#
# Version:
#	V2.02  Tue Aug 03 2020 12:45:00 revathy	Edit level 2
#
# Copyright notice:
#	This file copyright (C) 2020 by
#
#		MCCI Corporation
#		3520 Krums Corners Road
#		Ithaca, NY  14850
#
#	An unpublished work.  All rights reserved.
#
#	This file is proprietary information, and may not be disclosed or
#	copied without the prior permission of MCCI Corporation
#
# Author:
#	Prabhu Srinivasan, MCCI Corporation	June 2020
#
# Revision History:
#   2.01  Fri Jun 12 2020 17:02:00  prabhus
#	Module created.
#
#   2.02  Mon Aug 03 2020 12:45:00  revathy
#	Added common prefix for func's and part of reference line.
#
################################################################################

/*
Name:	weradiate_DT_init_DEC_template

Function:
	Google App Script Init function to start the DEC Template

Definition:
	function weradiate_DT_init_DEC_template(weradiate_DT_hClient, ss)

Description:
	This is an Init function for the DEC Report Template, it takes the
	parameter hClient and avails the required parameters from it and
	passes to the functions that populates the data in the spreadsheet.

Returns:
	Nothing.
*/

function weradiate_DT_init_DEC_template(weradiate_DT_hClient, ss)
	{
	var spreadsheet = ss;
	var weradiate_DT_allPiles = {};
	var weradiate_DT_allLocations={};
	var length = 0;

	/*get from date via function*/
	startdate = weradiate_DT_getFromDate(weradiate_DT_hClient);
	Logger.log(startdate);
	tFromDate = weradiate_DT_formatDate(startdate);

	/*get end date via function*/
	enddate = weradiate_DT_getToDate(weradiate_DT_hClient);
	Logger.log(enddate);
	tToDate = weradiate_DT_formatDate(enddate);

	weradiate_DT_sites = weradiate_DT_getAllSites(weradiate_DT_hClient)
	for(var site in weradiate_DT_sites)
		{
		weradiate_DT_allPiles[site] = [];
		weradiate_DT_allLocations[site] = {};
		weradiate_DT_piles = weradiate_DT_getAllPilesOfaSite(weradiate_DT_hClient,weradiate_DT_sites[site]);

		for(var pile_index = 0;pile_index < weradiate_DT_piles.length; pile_index++)
			{
			weradiate_DT_allPiles[site][pile_index]=weradiate_DT_piles[pile_index];
			}

		for(var pile in weradiate_DT_piles)
			{
			weradiate_DT_allLocations[site][pile] = [];
			weradiate_DT_locations = weradiate_DT_getAllLocationOfaPile(weradiate_DT_hClient, weradiate_DT_sites[site], weradiate_DT_piles[pile])
			weradiate_DT_allLocations[site][pile].push(weradiate_DT_locations);
			for( var location_index = 0;location_index < weradiate_DT_locations.length; location_index++)
				{
				weradiate_DT_allLocations[site][pile][location_index]= weradiate_DT_locations[location_index];
				}
			length = weradiate_DT_locations.length+length;
			}
		var workingSheet = spreadsheet.getSheets()[0];
		}
	weradiate_DT_Fillcontents_DEC_template(weradiate_DT_hClient, workingSheet, length, tFromDate, tToDate, weradiate_DT_sites, weradiate_DT_allPiles, weradiate_DT_allLocations,ss);
	}

/*
Name:	weradiate_DT_Fillcontents_DEC_template

Function:
	Google App Script function to fill the columns

Definition:
	function weradiate_DT_Fillcontents_DEC_template(
		weradiate_DT_hClient,
		workingSheet,
		length,
		tFromDate,
		tToDate,
		weradiate_DT_sites,
		weradiate_DT_allPiles,
		weradiate_DT_allLocations,
	spreadsheet
		)

Description:
	This function fills the received data as per the DEC report template
	w.r.t the Client locations in the spreadsheet and calls the Chart
	plotting function.

Returns:
	Nothing.
*/

function weradiate_DT_Fillcontents_DEC_template(
		weradiate_DT_hClient,
		workingSheet,
		length,
		tFromDate,
		tToDate,
		weradiate_DT_sites,
		weradiate_DT_allPiles,
		weradiate_DT_allLocations,
		spreadsheet
		)
	{
	var headerrow = 5;
	var datefilling_row = 6;
	var datefilling_col = 1;
	/*for 2D array*/
	const fnGet2D = function(v)
		{
		return  [v[0], v[1]] ;
		};
	/*for 1D array*/
	const fnGet1D = function(v)
		{
		return  v[2] ;
		};

	workingSheet.clear().clearFormats();
	var client_name = weradiate_DT_hClient.client;
	var sheet_name = workingSheet.setName( client_name + " - DEC-Report" );
	var day_heading_cell = 'A5';
	var date_heading_cell = 'B5';
	var qbg_placement = 'C2';
	var template_heading = 'F2';
	var detailed_heading = 'C3';
	var air_temp_heading = 'C5';
	var from_date_cell = 'E3';
	var to_date_cell = 'G3';
	var bin_no_cell = 'H2';
	var data_start_heading = "D5";
	var air_temp_column = 3;

	workingSheet.getRange(qbg_placement).setValue
	(client_name).setHorizontalAlignment('center')
		.setFontSize(14);
	workingSheet.getRange(template_heading).setValue("DEC-REPORT")
		.setHorizontalAlignment('center').setFontSize(14);
	workingSheet.getRange(detailed_heading).setValue("Daily BIN Temperature Tracking System")
		.setHorizontalAlignment('center').setFontSize(14);
	workingSheet.getRange(day_heading_cell).setValue("Day").setHorizontalAlignment('center')
		.setBorder(true, true, true, true, true, true, '#000000'
		, SpreadsheetApp.BorderStyle.SOLID);
	workingSheet.getRange(date_heading_cell).setValue("Date").setHorizontalAlignment('center')
		.setBorder(true, true, true, true, true, true, '#000000'
		, SpreadsheetApp.BorderStyle.SOLID);
	workingSheet.getRange(air_temp_heading).setValue("Air temp")
		.setHorizontalAlignment('center').setWrap(true)
		.setBorder(true, true, true, true, true, true, '#000000', SpreadsheetApp.BorderStyle.SOLID);
	workingSheet.getRange(from_date_cell).setValue("From Date : "+startdate).setWrap(true)
		.setHorizontalAlignment('center').setFontSize(11);
	workingSheet.getRange(to_date_cell).setValue("To Date : "+enddate).setWrap(true)
		.setHorizontalAlignment('center').setFontSize(11);
	workingSheet.getRange(bin_no_cell).setValue("Bin #:__________")
		.setHorizontalAlignment('center').setFontSize(14);
	workingSheet.getRange(headerrow,length+4).setValue("Notes").setWrap(true)
		.setHorizontalAlignment('center').setBorder(true, true, true, true, true, true, '#000000', SpreadsheetApp.BorderStyle.SOLID);
	HeaderData = weradiate_DT_generate_data(tFromDate, tToDate);
	Logger.log(datefilling_row, datefilling_col, HeaderData.length, 2);
	workingSheet.getRange(datefilling_row, datefilling_col, HeaderData.length, 2)
		.setHorizontalAlignment('center').setValues(HeaderData.map(fnGet2D))
		.setBorder(true, true, true, true, true, true, '#000000', SpreadsheetApp.BorderStyle.SOLID);
	workingSheet.getRange(headerrow, air_temp_column, HeaderData.length+1, air_temp_column)
		.setHorizontalAlignment('center').setBorder(true, true, true, true, true, true, '#000000', SpreadsheetApp.BorderStyle.SOLID);
	workingSheet.getRange(datefilling_row, length+1, HeaderData.length,4)
		.setHorizontalAlignment('center').setBorder(true, true, true, true, true, true, '#000000', SpreadsheetApp.BorderStyle.SOLID);

	date_heading = HeaderData.map(fnGet1D);
	var count = 0;
	for (var siteIndex = 0; siteIndex  < weradiate_DT_sites.length; siteIndex++)
		{
		for (var pileIndex = 0 ; pileIndex < weradiate_DT_allPiles[siteIndex].length; pileIndex++)
			{
			for (var locationIndex = 0; locationIndex < weradiate_DT_allLocations[siteIndex][pileIndex].length; locationIndex++)
				{
				weradiate_DT_column_datafill(weradiate_DT_hClient,tFromDate,tToDate,
					weradiate_DT_sites[siteIndex],
					weradiate_DT_allPiles[siteIndex][pileIndex],
					weradiate_DT_allLocations[siteIndex][pileIndex][locationIndex],
					workingSheet, workingSheet.getRange(data_start_heading).offset(0,count).getColumn(), date_heading);
				count++;
				}
			}
		}
	weradiate_DT_plot_chart_DEC_report(weradiate_DT_hClient, HeaderData.length, length, workingSheet,spreadsheet);
	}

/*
Name:	weradiate_DT_plot_chart_DEC_report

Function:
	Google App Script function to represent the chart for DEC Report

Definition:
	function weradiate_DT_plot_chart_DEC_report(
		weradiate_DT_hClient,
		length,
		no_of_columns,
		workingSheet,
		sheet_name,
	spreadsheet
		)

Description:
	This function fills the received data as per the DEC report template
	w.r.t the Client locations in the spreadsheet and calls the Chart
	plotting function.

Returns:
	Nothing.
*/

function weradiate_DT_plot_chart_DEC_report(
		weradiate_DT_hClient,
		length,
		no_of_columns,
		spreadsheet,
		book
		)
	{

	var activeSpreadsheet = book;
	var chart_data_start_row = 5;
	var chart_date_start_column = 2;
	var chart_data_start_column = 5;
	var reference_column = 4;
	var chart_flag = 0;

	chart_sheet = book.insertSheet().setName(weradiate_DT_hClient.client + " - Cumulative Chart");
	var xrange1 = spreadsheet.getRange(chart_data_start_row, chart_date_start_column).getA1Notation();
	var xrange2 = spreadsheet.getRange(chart_data_start_row+length, chart_date_start_column).getA1Notation();
	var yrange1 = spreadsheet.getRange(chart_data_start_row ,chart_data_start_column).getA1Notation();
	var yrange2 = spreadsheet.getRange(length+chart_data_start_row,no_of_columns+chart_data_start_column-1).getA1Notation();

	xrange = xrange1+':'+xrange2
	yrange = yrange1+':'+yrange2

	spreadsheet.insertColumns(reference_column);
	var ref1 = spreadsheet.getRange(chart_data_start_row, reference_column).getA1Notation();
	var ref2 = spreadsheet.getRange(length+chart_data_start_row, reference_column).getA1Notation();
	reference_range = ref1+':'+ref2;
	var refLineValue = weradiate_DT_getRefLineCount(weradiate_DT_hClient);

	spreadsheet.getRange(reference_range).setValue(refLineValue);
	spreadsheet.hideColumns(reference_column);
	weradiate_DT_createEmbeddedLineChart_(
		chart_sheet,
		spreadsheet,
		chart_flag,
		xrange,
		yrange,
		reference_range
		);
	}
