/*##############################################################################
#
# Module:  getapiurl.gs
#
# Function:
#	Google Spreadsheet Add-on URL functions.
#
# Version:
#	V2.01	Fri Jun 12 2020 17:02:00 sveluthambi Edit level 1
#
# Copyright notice:
#	This file copyright (C) 2020 by
#
#		MCCI Corporation
#		3520 Krums Corners Road
#		Ithaca, NY  14850
#
#	An unpublished work.  All rights reserved.
#
#	This file is proprietary information, and may not be disclosed or
#	copied without the prior permission of MCCI Corporation
#
# Author:
#	Sivaprakash Veluthambi, MCCI Corporation	June 2020
#
# Revision History:
#   2.01  Fri Jun 12 2020 17:02:00  sveluthambi
#	Module created.
#
################################################################################

/*

Name:	getClientInfoUrl

Function:
	Google App Script function to get Client Info URL

Definition:
	function getClientInfoUrl()

Description:
	This is an Init function for the DEC Report Template, it takes the
	parameter hClient and avails the required parameters from it and
	passes to the functions that populates the data in the spreadsheet.

Returns:
	Returns Client URL.

*/

function getClientInfoUrl() {
	var clientInfoUrl = 'https://iotdashboard.mcci.com/apiserver/client?cname=';

	return clientInfoUrl;
	}

/*

Name:	getDataUrl

Function:
	Google App Script function to get location data URL

Definition:
	function getDataUrl()

Description:
	This is an Init function for the DEC Report Template, it takes the
	parameter hClient and avails the required parameters from it and
	passes to the functions that populates the data in the spreadsheet.

Returns:
	Returns Get Data Query URL.

*/

function getDataUrl() {
	var getDataUrl =  'https://iotdashboard.mcci.com/apiserver/dread?cname=';

	return getDataUrl;
	}
