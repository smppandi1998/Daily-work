/*##############################################################################
#
# Module:  notify.gs
#
# Function:
#	Google Spreadsheet Add-on that Installs & Initiates the Add-on.
#
# Version:
#	V2.01	Mon Jun 15 2020 17:02:00 sveluthambi	Edit level 1
#
# Copyright notice:
#	This file copyright (C) 2020 by
#
#		MCCI Corporation
#		3520 Krums Corners Road
#		Ithaca, NY  14850
#
#	An unpublished work.  All rights reserved.
#
#	This file is proprietary information, and may not be disclosed or
#	copied without the prior permission of MCCI Corporation
#
# Author:
#	Sivaprakash Veluthambi, MCCI Corporation	June 2020
#
# Revision History:
#   2.01  Mon Jun 15 2020 17:02:00  sveluthambi
#	Module created.
#
##############################################################################*/
/*

Name:	errorMsg

Function:
	Google App Script function to display error message

Definition:
	function errorMsg(msg)

Description:
	This function receives the error message and shows up when a particular
    functionality is failed

Returns:
	Nothing.

*/
function errorMsg(msg) 
	{
	var ui = SpreadsheetApp.getUi();
	ui.alert('ERROR: \n' + msg);
	}

/*

Name:	alertMsg

Function:
	Google App Script function to display alert message

Definition:
	function alertMsg(msg)

Description:
	This function receives the alert message and shows up when calling
    functionality throws error

Returns:
	Nothing.

*/
function alertMsg(msg) 
	{
	var ui = SpreadsheetApp.getUi();
	ui.alert(msg);
	}

/*

Name:	logMsg

Function:
	Google App Script function to log an information

Definition:
	function logMsg(msg)

Description:
	This function receives the log message and shows up

Returns:
	Nothing.

*/

function logMsg(msg) 
	{
	Logger.log(msg);
	}
