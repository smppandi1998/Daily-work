# Google Sheet Add-on

Client Witchhazel Windsor Project - Google Sheet Add-on for the WeRadiate Data Template