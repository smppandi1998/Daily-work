/*##############################################################################
#
# Module:  openclienthandler
#
# Function:
#	To get client handling information
#
# Version:
#	V2.02	Mon Aug 03 2020 13:02:00 revathy	Edit level 2
#
# Copyright notice:
#	This file copyright (C) 2020 by
#
#		MCCI Corporation
#		3520 Krums Corners Road
#		Ithaca, NY  14850
#
#	An unpublished work.  All rights reserved.
#
#	This file is proprietary information, and may not be disclosed or
#	copied without the prior permission of MCCI Corporation
#
# Author:
#	Sivaprakash Veluthambi, MCCI Corporation	June 2020
#
# Revision History:
#   2.01  Mon Jun 15 2020 17:02:00  sveluthambi
#	Module created.
#	2.02  Mon Aug 03 2020 13:02:00  revathyg
#	Common prefix for all functions
#
################################################################################*/

/*

Name:	weradiate_DT_initClient

Function:
	Google Script Add-on function for Storing Client Info

Definition:
	function weradiate_DT_initClient(
		fromDate,
		toDate,
		aggregator,
		template,
		refLineCnt
		)

Description:
	This function stores the From Date, To date, Aggregator, Template,
	Reference Line Values in the Document property

Returns:
	Nothing.

*/

function weradiate_DT_initClient
	(
	fromDate,
	toDate,
	aggregator,
	template,
	refLineCnt
	)
	{

	docProperty.setProperty('selectedFromDate', fromDate);
	docProperty.setProperty('selectedToDate', toDate);
	docProperty.setProperty('selectedAggregator', aggregator);
	docProperty.setProperty('selectedTemplate', template);
	docProperty.setProperty('selectedRefCount', refLineCnt);
	}

/*

Name:	weradiate_DT_openClientHandler

Function:
	Function to generate client handle

Definition:
	function weradiate_DT_openClientHandler(clientName)

Description:
	This function that gets the client name as parameter and creates Client
	handle object to hold the client information

Returns:
	Object to handle client information

*/

function weradiate_DT_openClientHandler(clientName)
	{
	var weradiate_DT_hClient = {};
	var weradiate_DT_sites = [];
	var weradiate_DT_piles = {};
	var weradiate_DT_locations = {};

	var clientInfoUrl = getClientInfoUrl();
	var url = clientInfoUrl + clientName;
    	Logger.log("url-->", url) ;
	response = sendRequest(url, 'get', docProperty.getProperty('token'));

	if(response == '' || response == null || response.message)
		{
		alertMsg('Can\'t get client information');
		return false;
		}

	weradiate_DT_hClient.client = clientName;
	weradiate_DT_hClient.token = docProperty.getProperty('token');
	weradiate_DT_hClient.fromDate = docProperty.getProperty('selectedFromDate');
	weradiate_DT_hClient.toDate = docProperty.getProperty('selectedToDate');
	weradiate_DT_hClient.aggregator = docProperty.getProperty('selectedAggregator');
	weradiate_DT_hClient.template = docProperty.getProperty('selectedTemplate');
	weradiate_DT_hClient.refLineCount = docProperty.getProperty('selectedRefCount');
	Logger.log("response.results-->", response.results)
	Logger.log("response-->", response) ;

	for(var site in response.results.sites)
		{
		weradiate_DT_sites.push(site);
		}

	for(var site in response.results.sites)
		{
		weradiate_DT_piles[site] = [];
		for(var pile in response.results.sites[site])
			{
			weradiate_DT_piles[site].push(pile);
			}
		}

	for(var site in response.results.sites)
		{

		weradiate_DT_locations[site] = {};
		for(var pile in response.results.sites[site])
			{
			weradiate_DT_locations[site][pile] = [];
			for(var location in response.results.sites[site][pile])
				{
				weradiate_DT_locations[site][pile].push(response.results.sites[site][pile][location]);
				}
			}
		}

	weradiate_DT_hClient.sites = weradiate_DT_sites;
	weradiate_DT_hClient.piles = weradiate_DT_piles;
	weradiate_DT_hClient.locations = weradiate_DT_locations;

	return weradiate_DT_hClient;
	}

/*

Name:	weradiate_DT_getToken

Function:
	Function to get token

Definition:
	function weradiate_DT_getToken(weradiate_DT_hClient)

Description:
	This function returns the token for the resp. client handle

Returns:
	Returns token string

*/

function weradiate_DT_getToken(weradiate_DT_hClient)
	{

	weradiate_DT_token = weradiate_DT_hClient.token;
	return weradiate_DT_token;
	}

/*

Name:	weradiate_DT_getFromDate

Function:
	Function to get From Date

Definition:
	function weradiate_DT_getFromDate(weradiate_DT_hClient)

Description:
	This function returns the From date for the resp. client handle

Returns:
	Returns From Date value as string

*/

function weradiate_DT_getFromDate(weradiate_DT_hClient)
	{

	weradiate_DT_fromDate = weradiate_DT_hClient.fromDate;
	return weradiate_DT_fromDate;
	}

/*
Name:	weradiate_DT_getToDate

Function:
	Function to get To Date

Definition:
	function weradiate_DT_getToDate(weradiate_DT_hClient)

Description:
	This function returns the To date for the resp. client handle

Returns:
	Returns To Date value as string

*/

function weradiate_DT_getToDate(weradiate_DT_hClient)
	{

	weradiate_DT_toDate = weradiate_DT_hClient.toDate;
	return weradiate_DT_toDate;
	}

/*

Name:	weradiate_DT_getAggregator

Function:
	Function to get Aggregator

Definition:
	function weradiate_DT_getAggregator(weradiate_DT_hClient)

Description:
	This function returns the aggregator for the resp. client handle

Returns:
	Returns aggregator value as string

*/

function weradiate_DT_getAggregator(weradiate_DT_hClient)
	{

	weradiate_DT_aggregator = weradiate_DT_hClient.aggregator;
	return weradiate_DT_aggregator;
	}

/*

Name:	weradiate_DT_getTemplate

Function:
	Function to get selected template model

Definition:
	weradiate_DT_getTemplate(weradiate_DT_hClient)

Description:
	This function returns the selected template model for the
	resp. client handle

Returns:
	Returns template value as string

*/

function weradiate_DT_getTemplate(weradiate_DT_hClient)
	{

	weradiate_DT_template = weradiate_DT_hClient.template;
	return weradiate_DT_template;
	}

/*

Name:	weradiate_DT_getRefLineCount

Function:
	Function to return entered Reference line count value

Definition:
	function weradiate_DT_getRefLineCount(weradiate_DT_hClient)

Description:
	This function returns the reference line value for the
	resp. client handle

Returns:
	Return entered reference line count value

*/

function weradiate_DT_getRefLineCount(weradiate_DT_hClient)
	{

	weradiate_DT_refLineCount = weradiate_DT_hClient.refLineCount;
	return weradiate_DT_refLineCount;
	}

/*

Name:	weradiate_DT_getAllSites

Function: To get all site information


Definition:
	function weradiate_DT_getAllSites(weradiate_DT_hClient)

Description:
	This function returns the array of sitelist for the resp. client handle


Returns:
	Return the array of sites for the resp. client handle

*/

function weradiate_DT_getAllSites(weradiate_DT_hClient)
	{

	weradiate_DT_siteList = weradiate_DT_hClient.sites;
	return weradiate_DT_siteList;
	}

/*

Name:	weradiate_DT_getAllPilesOfaSite

Function: Get all piles information from a site


Definition:
	function weradiate_DT_getAllPilesOfaSite(weradiate_DT_hClient, siteName)

Description:
	This function return array of pile list for the resp. client handle
	and the site name passed to this function

Returns:
	Return the array of piles for the resp. client handle & site name

*/

function weradiate_DT_getAllPilesOfaSite(weradiate_DT_hClient, siteName)
	{

	weradiate_DT_pileList = weradiate_DT_hClient.piles[siteName];
	return weradiate_DT_pileList;

	}

/*

Name:	weradiate_DT_getAllLocationOfaPile

Function: Get all location information from a pile

Definition:
	function weradiate_DT_getAllLocationOfaPile(
		weradiate_DT_hClient,
		siteName,
		pileName
		)

Description:
	This function returns the array of location for the resp. client handle,
	site name, pile name

Returns:
	Returns the array of locations for the resp. client handle, sitename,
	pilename

*/

function weradiate_DT_getAllLocationOfaPile(
	weradiate_DT_hClient,
	siteName,
	pileName
	)
	{

	weradiate_DT_locationList = weradiate_DT_hClient.locations[siteName][pileName];
	return weradiate_DT_locationList;
	}

/*

Name:	weradiate_DT_getDataOfaLocation

Function: Get a location data

Definition:
	function weradiate_DT_getDataOfaLocation(
		weradiate_DT_hClient,
		siteName,
		pileName,
		locationName
		)

Description:
	This function returns the data of a location for the resp.
	client handle, site name, pile name, location name

Returns:
	Return data of location as Object for the resp. client handle,
	sitename, pilename, locationname

*/

function weradiate_DT_getDataOfaLocation(weradiate_DT_hClient, siteName, pileName, locationName)
	{


    var fromDate = weradiate_DT_iso_date_format(weradiate_DT_getFromDate(weradiate_DT_hClient));
    var toDate = weradiate_DT_iso_date_format(weradiate_DT_getToDate(weradiate_DT_hClient));
	weradiate_DT_locationData = weradiate_DT_getDataOfaLocationV2(
				weradiate_DT_hClient,
				fromDate,
				toDate,
				weradiate_DT_getAggregator(weradiate_DT_hClient),
				siteName,
				pileName,
				locationName
				);

	return weradiate_DT_locationData;
	}
/*

Name:	weradiate_DT_iso_date_format

Function:
	Gets ISO date format with string date input

Definition:
	weradiate_DT_iso_date_format(
	      date_string
	      )

Description:
	This function return the date in ISO format with string format of a date.

Returns:
	Return dats in ISO format

*/
function weradiate_DT_iso_date_format(date_string)
   {
    var date = new Date(date_string);
    var dd = date.getDate();
    var mm = date.getMonth()+1;
    var yyyy = date.getFullYear();

    if(dd<10)
	{
	 dd='0'+dd;
	}

   if(mm<10)
       {
	mm='0'+mm;
       }
   date_iso = mm+'-'+dd+'-'+yyyy;
   return date_iso
   }

/*

Name:	weradiate_DT_getDataOfaLocationV2

Function:
	Get a location data

Definition:
	function weradiate_DT_getDataOfaLocationV2(
		weradiate_DT_hClient,
		fromDate,
		toDate,
		aggregator,
		siteName,
		pileName,
		locationName
		)

Description:
	This function return the data of a location when called with client handle,
	From data, To date, aggregator, site name, pile name, location name

Returns:
	Return data of location as Object

*/

function weradiate_DT_getDataOfaLocationV2(
	weradiate_DT_hClient,
	fromDate,
	toDate,
	aggregator,
	siteName,
	pileName,
	locationName
	)
	{
	var dataurl = getDataUrl();
	var url = dataurl
	  + weradiate_DT_hClient.client
	  + '&site='
	  + siteName
	  + '&pile='
	  + pileName
	  + '&location='
	  + locationName
	  + '&fncode='
	  + aggregator
	  + '&fmdate='
	  + fromDate
	  + '&todate='
	  + toDate;
	var methodType = 'get';
	authToken = weradiate_DT_hClient.token;
    Logger.log("URL: ",url);

	weradiate_DT_result = sendRequest(url, methodType, authToken);
	return weradiate_DT_result;
	};
