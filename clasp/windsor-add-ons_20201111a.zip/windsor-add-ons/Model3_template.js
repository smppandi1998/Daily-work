/*##############################################################################
#
# Module:  template_model3.gs
#
# Function:
#	Google Spreadsheet Add-on that populates the data from server into spreadsheet.
#
# Version:
#	V2.02	Mon Aug 03 2020 12:45:00 revathy	Edit level 2
#
# Copyright notice:
#	This file copyright (C) 2020 by
#
#		MCCI Corporation
#		3520 Krums Corners Road
#		Ithaca, NY  14850
#
#	An unpublished work.  All rights reserved.
#
#	This file is proprietary information, and may not be disclosed or
#	copied without the prior permission of MCCI Corporation
#
# Author:
#	Revathy Gajendran, MCCI Corporation	June 2020
#
# Revision History:
#   2.01  Mon Jun 17 2020 17:02:00  revathy
#	Module created.
#	2.02  Mon Aug 03 2020 12:45:00  revathy
#	Common prefix and reference column position change for color coding
#
##############################################################################*/

/*
Name:	weradiate_DT_init_template3

Function:
	Google App Script function to init template model 3

Definition:
	function weradiate_DT_init_template3(
		weradiate_DT_hClient,
		weradiate_DT_site,
		site_no,
	spreadsheet
		)

Description:
	This function initiates information for data filling in the spreadsheet
	w.r.t the Model 3 template

Returns:
	Nothing.
*/

function weradiate_DT_init_template3(
	weradiate_DT_hClient,
	weradiate_DT_site,
	site_no,
	book
	)
	{
	//var spreadsheet = SpreadsheetApp.getActiveSpreadsheet();
	var client_name = weradiate_DT_hClient.client;

	fromDate = weradiate_DT_getFromDate(weradiate_DT_hClient);
	toDate = weradiate_DT_getToDate(weradiate_DT_hClient);
	tFromDate = weradiate_DT_formatDate(fromDate);
	tToDate = weradiate_DT_formatDate(toDate);

	var startdate = tFromDate;
	var enddate = tToDate;

	weradiate_DT_piles = weradiate_DT_getAllPilesOfaSite(weradiate_DT_hClient,weradiate_DT_site);
	Logger.log(weradiate_DT_piles);

	var sheet_name = weradiate_DT_site+'|'+weradiate_DT_piles[0];
	var day_heading_cell = 'B5';
	var date_heading_cell = 'C5';
	var data_heading_cell = 'D5';
	Logger.log('site_no: , name assigned',site_no,sheet_name);
	var title = client_name + ' Template (Model 3)';
	var title_cell = 'D2';

	if(site_no == 0)
		{
		book.getSheets()[0].setName(sheet_name);
		}
	else
		{
		book.insertSheet().setName(sheet_name);
		}

	//Logger.log('1st sheetname: ',spreadsheet.getSheetName());
	for ( var pile = 0; pile < weradiate_DT_piles.length; pile++)
		{
		sheet_name = weradiate_DT_site+'|'+ weradiate_DT_piles[pile];
		spreadsheet = book.getSheetByName(sheet_name);
		weradiate_DT_TitleCard(spreadsheet,title,title_cell);
		Logger.log('start sheetname: ',spreadsheet.getSheetName());
		spreadsheet.getRange(day_heading_cell).activate();
		spreadsheet.getCurrentCell().setValue('Day');
		spreadsheet.getActiveRangeList().setHorizontalAlignment('center');
		spreadsheet.getRange(date_heading_cell).activate();
		spreadsheet.getCurrentCell().setValue('Date');
		spreadsheet.getActiveRangeList().setHorizontalAlignment('center');
		spreadsheet.getRange(data_heading_cell).activate();
		spreadsheet.getRange(day_heading_cell + ':' + data_heading_cell).activate();
		spreadsheet.getActiveRangeList().
		setBorder(true, true, true, true, true, true, '#000000'
		, SpreadsheetApp.BorderStyle.SOLID)
		.setFontSize(10);

		/*generating an array of list of dates for specifed range
		to compare with json response*/
		HeaderData = weradiate_DT_generate_data(startdate, enddate);
		const fnGet2D = function(v) {
			return  [v[0], v[1]] ;
			};
		const fnGet1D = function(v) {
			return  v[2] ;
			};

		dateFilling_start_row = 6;
		dateFilling_start_column = 2;
		dateFilling_last_column = 2;
		spreadsheet.getRange(dateFilling_start_row, dateFilling_start_column, HeaderData.length, dateFilling_last_column)
		.setHorizontalAlignment('center').setValues(HeaderData.map(fnGet2D))
		.setBorder(true, true, true, true, true, true, '#000000', SpreadsheetApp.BorderStyle.SOLID);
		date_heading = HeaderData.map(fnGet1D);
		Logger.log("date_heading");
		Logger.log(date_heading);
		datacolumn = 0;
		weradiate_DT_locations = weradiate_DT_getAllLocationOfaPile(weradiate_DT_hClient, weradiate_DT_site, weradiate_DT_piles[pile]);
		Logger.log(weradiate_DT_site, weradiate_DT_piles[pile], weradiate_DT_locations);
		for (var location=0; location < weradiate_DT_locations.length; location++)
			{
			spreadsheet.getRange(data_heading_cell).offset(0, datacolumn).activate();
			weradiate_DT_column_datafill(weradiate_DT_hClient,
				tFromDate,
				tToDate,
				weradiate_DT_site,
				weradiate_DT_piles[pile],
				weradiate_DT_locations[location],
				spreadsheet,spreadsheet.getRange(data_heading_cell).
				offset(0, datacolumn).getColumn(),
				date_heading);

			datacolumn++;
			}

		weradiate_DT_plot_chart_template3(
			HeaderData.length,
			weradiate_DT_locations.length,
			sheet_name,
			spreadsheet,
			sheet_name
		);

		if((pile+1)< weradiate_DT_piles.length)
			{
			var new_sheet =  book.getSheetByName(weradiate_DT_site+'|'+weradiate_DT_piles[pile+1]);
			if (new_sheet != null)
				{
				book.deleteSheet(new_sheet);
				}
			book.insertSheet().setName(weradiate_DT_site+'|'+weradiate_DT_piles[pile+1]);
			Logger.log('end sheetname: ',spreadsheet.getSheetName());
			}
		}
	}

/*
Name:	weradiate_DT_plot_chart_template3

Function:
	Google App Script function to provide Chart representation for Model 2

Definition:
	function weradiate_DT_plot_chart_template3
		(
		length,
		no_of_columns,
		chart_name,
		spreadsheet,
		sheet_name
		)
Description:
	This function plots the cumulative representation for the data in a separate sheet

Returns:
	Nothing.

*/

function weradiate_DT_plot_chart_template3(
	length,
	no_of_columns,
	chart_name,
	spreadsheet,
	sheet_name
	)
	{
	chart_data_start_row = 5;
	chart_data_start_column = 3;
	reference_start_row = 5;
	chart_flag = 1;

	var xrange1 = spreadsheet.getRange(chart_data_start_row, chart_data_start_column).getA1Notation();
	var yrange2 = spreadsheet.getRange(chart_data_start_row + length, chart_data_start_column + no_of_columns +1).getA1Notation();
	range = xrange1+':'+yrange2;

	reference_range_row = 5;
	reference_column = 4;
	spreadsheet.insertColumns(reference_column);
	var ref1 = spreadsheet.getRange(reference_range_row, reference_column).getA1Notation();
	var ref2 = spreadsheet.getRange(reference_range_row + length, reference_column).getA1Notation();
	reference_range = ref1+':'+ref2;
	Logger.log(reference_range);
	var refLineValue = weradiate_DT_getRefLineCount(weradiate_DT_hClient);
	spreadsheet.getRange(reference_range).setValue(refLineValue);
	spreadsheet.hideColumns(reference_column);

	chart_position = no_of_columns + 6;
	weradiate_DT_createEmbeddedLineChart_(
		spreadsheet,
		spreadsheet,
		chart_flag,
		range,
		chart_position,
		reference_range
		);
	}
