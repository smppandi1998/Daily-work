/*##############################################################################
#
# Module:  loadtemplate.gs
#
# Function:
#	Google Spreadsheet Add-on that loads customized template in the spreadsheet.
#
# Version:
#	V2.02  Tue Jul 14 2020 12:45:00 revathy	Edit level 2
#
# Copyright notice:
#	This file copyright (C) 2020 by
#
#		MCCI Corporation
#		3520 Krums Corners Road
#		Ithaca, NY  14850
#
#	An unpublished work.  All rights reserved.
#
#	This file is proprietary information, and may not be disclosed or
#	copied without the prior permission of MCCI Corporation
#
# Author:
#	Revathy Gajendran, MCCI Corporation	June 2020
#
# Revision History:
#   2.01  Mon Jun 15 2020 17:02:00  revathy
#	Module created.
#
#   2.02  Tue Jul 14 2020 12:45:00  revathy
#	Added common prefix and Client Looping.
#
##############################################################################*/


/*

Name:	weradiate_DT_searchFile

Function:
	Google App Script function to search the file in the drive with the Name

Definition:
	function weradiate_DT_searchFile(FileIterator, FileNameString)

Description:
	This function searches for the file in the drive with the name provided and if the
	file is located returns the handle to access the file.

Returns:
	Handle for the located file or NULL.

*/

function weradiate_DT_searchFile(FileIterator, FileNameString)
	{
	Logger.log("FileNameString: ", FileNameString);
	var ss = null;

	if (FileIterator == null)
		var FileIterator = DriveApp.getFiles();
        DriveApp.getRootFolder().getId()

	if (FileIterator != null)
		{
		do
			{
			if (FileIterator.hasNext() == false)
				{
				break;
				}
			var file = FileIterator.next();
			Logger.log("File Name: ", file.getName());
			if (file.getName() == FileNameString)
				{
				ss = SpreadsheetApp.openByUrl(file.getUrl());
				Logger.log("Located the file in drive: ", ss.getName());
				ss.insertSheet();
				var newSheetName = ss.getSheetName();
				var allSheets = ss.getSheets();

				for (var i in allSheets)
					{
					if(allSheets[i].getName() != newSheetName)
						{
						ss.deleteSheet(allSheets[i]);
						}
					}
				break;
				}
			Logger.log("Is there a next file: ", FileIterator.hasNext());
			} while (FileIterator.hasNext());
		}
	return ss;
	}

/*

Name:	weradiate_DT_loadTemplate

Function:
	Google App Script init function which loads the Customized Templates

Definition:
	function weradiate_DT_loadTemplate(clientList)

Description:
	This function initializes the required parameters and calls up the
	respective functions that loads the user selected Template Model in the
	spreadsheet.

Returns:
	Nothing.

*/

function weradiate_DT_loadTemplate(clientList)
	{
	Logger.log("clientList: ", clientList);
	date_time = new Date().toISOString();
	var ss = null;
	for(var client in clientList)
		{
		weradiate_DT_hClient= weradiate_DT_openClientHandler(clientList[client]);
		template_name = weradiate_DT_getTemplate(weradiate_DT_hClient);
		if (template_name != 'DEC Report' && template_name != 'Model1' && template_name != 'Model2' && template_name != 'Model3')
			{
			errorMsg('Unrecognized template, Please try again');
			return false;
			}
		Logger.log("client list length.....", clientList.length )  ;
		if(clientList.length == 1)
			{
			var FileNameString =  clientList[client] + "_" + template_name;
			Logger.log("FileNameString: ", FileNameString);

			// Calling search file func; passing 'null' since no specific folder
			// search in drive folder only

			ss = weradiate_DT_searchFile(null, FileNameString);

			Logger.log("ss single client after checking if file available or not ", ss);

			// if the ss is null after the search, create a new file
			if (ss == null)
				{
				ss = SpreadsheetApp.create(FileNameString);
				Logger.log ("Created New file: ", ss.getName());
				}
			}
		else
			{
			Logger.log("In else block of multiple clients..................." + clientList[client]);
			//var ssAdmin = null;
			var folder = null;
			var file = null;
			var folders = DriveApp.getFoldersByName("Workbook-Admin");

			//Check if Workbook-Admin Folders exist in do-while loop
			if (folders.hasNext() == true)
				{
				var folder = folders.next();
				Logger.log(folder);
				Logger.log("Workbook-Admin folder available");
				var admin_folder_Id = folder.getId();
				var FileNameString =  clientList[client] + "_" + template_name+ "-Admin";
				Logger.log("FileNameString: ", FileNameString);
				var FileIterator = folder.getFiles();

				// Calling search file func
				ss = weradiate_DT_searchFile(FileIterator, FileNameString);
				// AFter file-while loop if there is no $(FileNameString) FILE within admin folder
				if (ss == null)
					{
					var file_name = clientList[client] + "_" + template_name+ "-Admin";
					var ss_admin = SpreadsheetApp.create(file_name);
					var files = DriveApp.getRootFolder().getFilesByName(file_name);
					while (files.hasNext())
						{
						var file = files.next();
						var destination = DriveApp.getFolderById(DriveApp.getFoldersByName("Workbook-Admin").next().getId());
				//                      file.makeCopy(destination);
				//                      DriveApp.getRootFolder().setSharing(DriveApp.Access.PRIVATE, DriveApp.Permission.FILE_ORGANIZER);
				//                      destination.getFilesByName("Copy of " + file_name ).next().setName(file_name);
						DriveApp.getRootFolder().setSharing(DriveApp.Access.PRIVATE, DriveApp.Permission.FILE_ORGANIZER);
						folder.addFile(file);
						var pull = DriveApp.getRootFolder();
						pull.removeFile(file);
						ss_admin = SpreadsheetApp.openById(destination.getFilesByName(file_name).next().getId());
						break;
						}
					Logger.log ("Created New file in workbook-admin folder : ", ss_admin.getName());
					ss = ss_admin;
					}
				else
					{
					Logger.log ("Got the file: ", ss.getName());
					}
				}
                	// After folder while loop if there is no workbook-admin folder - create folder and relevant file
			else
				{
				Logger.log("No Folder, so creating folder..");

				var ssCreateFolder = SpreadsheetApp.create(clientList[client] + "_" + template_name+ "-Admin");
				var temp = DriveApp.getFileById(ssCreateFolder.getId());

				folder = DriveApp.createFolder("Workbook-Admin");
				//folder = DriveApp.getFolderById(workbook_admin_folderID);
				folder.addFile(temp);
				DriveApp.getRootFolder().removeFile(temp);
				Logger.log("Created Name: ", ssCreateFolder.getName());

				// Handing over the created newly handle
				ss = ssCreateFolder;
				}
			}

		if (ss != null)
			{
			if(template_name == 'DEC Report')
				{
				weradiate_DT_init_DEC_template(weradiate_DT_hClient, ss);
				}
			else if(template_name == 'Model1')
				{
				weradiate_DT_init_model1template(weradiate_DT_hClient, ss);
				}
			else if(template_name == 'Model2')
				{
				weradiate_DT_model2_template(weradiate_DT_hClient, ss);
				}
			else if(template_name == 'Model3')
				{
				weradiate_DT_model3_template(weradiate_DT_hClient, ss);
				}
			else
				{
				errorMsg('Unrecognized template');
				return false;
				}
			url = ss.getUrl();
			weradiate_openURL(url);
			}
		else
			{
			Logger.log ("Didn't get the Spreadsheet handle!!!")
			}
		}

	}

/*

Name:	weradiate_DT_model2_template

Function:
	Google App Script function that passes required arguments to the Model2 Template

Definition:
	function weradiate_DT_model2_template(weradiate_DT_hClient)

Description:
	This function fetches the site information from the utility function
	and pass it to the Model 2 Template loading function

Returns:
	Nothing.

*/

function weradiate_DT_model2_template(weradiate_DT_hClient,ss)
	{
	var weradiate_DT_sites =  weradiate_DT_getAllSites(weradiate_DT_hClient);

	for(var site in weradiate_DT_sites) {
		sheet_index = 0
		var spreadsheet = ss.insertSheet(sheet_index);

		Logger.log(weradiate_DT_sites[site]);
		weradiate_DT_init_template2(weradiate_DT_hClient, weradiate_DT_sites[site],spreadsheet,ss);
		}
	}

/*

Name:	weradiate_DT_model3_template

Function:
	Google App Script function that passes required arguments to the Model3 Template

Definition:
	function weradiate_DT_model3_template(weradiate_DT_hClient)

Description:
	This function fetches the site information from the utility function
	and pass it to the Model 3 Template loading function

Returns:
	Nothing.

*/

function weradiate_DT_model3_template(weradiate_DT_hClient,ss)
	{
	var weradiate_DT_sites =  weradiate_DT_getAllSites(weradiate_DT_hClient);

	for(var site in weradiate_DT_sites)
		{
		Logger.log(weradiate_DT_sites[site]);
		weradiate_DT_init_template3(weradiate_DT_hClient, weradiate_DT_sites[site],site,ss);
		}
	}

/*

Name:	weradiate_DT_formatDate

Function:
	Google App Script function that formats the date to yyyy-mm-dd

Definition:
	function weradiate_DT_formatDate(dateVal)

Description:
	Changes the date format to yyyy-mm-dd in the Template.

Returns:
	Nothing.

*/

function weradiate_DT_formatDate(dateVal)
	{
	var dateVal = new Date(dateVal);
	d = dateVal.getDate();
	m = dateVal.getMonth() + 1;
	y = dateVal.getFullYear();
	fDate = y + "-" + m + "-" + d;

	return fDate;
	}

/*

Name:	weradiate_openURL

Function:
	Google App Script function that opens Spreadsheet file in a separate tab

Definition:
	function weradiate_openURL(url)

Description:
	Opens Spreadsheet file in a separate tab

Returns:
	Nothing.

*/

function weradiate_openURL(url)
	{
	var html = HtmlService.createHtmlOutput('<html><script>'
		+'window.close = function(){window.setTimeout(function(){google.script.host.close()},9)};'
		+'var a = document.createElement("a"); a.href="'+url+'"; a.target="_blank";'
		+'if(document.createEvent){'
		+'  var event=document.createEvent("MouseEvents");'
		+'  if(navigator.userAgent.toLowerCase().indexOf("firefox")>-1){window.document.body.append(a)}'
		+'  event.initEvent("click",true,true); a.dispatchEvent(event);'
		+'}else{ a.click() }'
		+'close();'
		+'</script>'
		// Offer URL as clickable link in case above code fails.
		+'<body style="word-break:break-word;font-family:sans-serif;">Failed to open automatically. <a href="'+url+'" target="_blank" onclick="window.close()">Click here to proceed</a>.</body>'
		+'<script>google.script.host.setHeight(40);google.script.host.setWidth(410)</script>'
		+'</html>')
		.setWidth( 90 ).setHeight( 1 );
	SpreadsheetApp.getUi().showModalDialog( html, "Opening ..." );
	}