/*##############################################################################
#
# Module:  chart.gs
#
# Function:
#	Google Spreadsheet Add-on that provide chart representation in spreadsheet.
#
# Version:
#	V2.02  Tue Jul 14 2020 12:45:00 revathy	Edit level 2
#
# Copyright notice:
#	This file copyright (C) 2020 by
#
#		MCCI Corporation
#		3520 Krums Corners Road
#		Ithaca, NY  14850
#
#	An unpublished work.  All rights reserved.
#
#	This file is proprietary information, and may not be disclosed or
#	copied without the prior permission of MCCI Corporation
#
# Author:
#	Revathy Gajendran, MCCI Corporation	June 2020
#
# Revision History:
#   2.01  Mon Jun 15 2020 17:02:00  revathy
#	Module created.
#
#   2.02  Tue Jul 14 2020 12:45:00  revathy
#	Added code for Red & Thick borders.
#
##############################################################################*/

/*

Name:	weradiate_DT_createEmbeddedLineChart_

Function:
	Google App Script function for Chart representing for the received data

Definition:
	function weradiate_DT_createEmbeddedLineChart_(
		baseSheet,
		dataSheet,
		cumulative_flag,
		x,
		y,
		reference_range
		)

Description:
	This function provides a chart representation for the requesed data

Returns:
	Nothing.

*/

function weradiate_DT_createEmbeddedLineChart_(baseSheet, dataSheet, cumulative_flag, x, y, reference_range, reference_series_index)
	{
	var hAxisOptions = {
	slantedText: true,
	slantedTextAngle: 60,
	gridlines: {
		count: 12
		}
	};

	var lineChartBuilder = baseSheet.newChart().asLineChart();


	if (cumulative_flag ==0){
		var chart = lineChartBuilder
		.addRange(dataSheet.getRange(x))
        .addRange(dataSheet.getRange(reference_range))
		.addRange(dataSheet.getRange(y))
		.setPosition(5, 5, 0, 0)
		.setTitle(baseSheet.getSheetName())
		.setNumHeaders(1)
		.setLegendPosition(Charts.Position.RIGHT)
		.setOption('hAxis', hAxisOptions)
        .setOption('series.0.color', '#ff0000')
        .setOption('series.0.lineWidth', 4)
        .setOption('series.1.color', '#0000ff')

		.build();
	}
	else{
		var chart = lineChartBuilder
		.addRange(dataSheet.getRange(x))
        //.addRange(baseSheet.getRange(reference_range))
		.setPosition(5, y, 0, 0)
		.setTitle(baseSheet.getSheetName())
		.setNumHeaders(1)
		.setLegendPosition(Charts.Position.RIGHT)
		.setOption('hAxis', hAxisOptions)
        .setOption('series.0.color', '#ff0000')
        .setOption('series.0.lineWidth', 4)
        .setOption('series.1.color', '#0000ff')
		.build();
	}

	baseSheet.insertChart(chart);
}
