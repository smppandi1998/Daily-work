/*##############################################################################
#
# Module:  data_utility_functions.gs
#
# Function:
#	Google Spreadsheet Add-on utility functions that populates the data from server into spreadsheet.
#
# Version:
#	V2.01	Mon Jun 18 2020 17:02:00 sveluthambi	Edit level 1
#
# Copyright notice:
#	This file copyright (C) 2020 by
#
#		MCCI Corporation
#		3520 Krums Corners Road
#		Ithaca, NY  14850
#
#	An unpublished work.  All rights reserved.
#
#	This file is proprietary information, and may not be disclosed or
#	copied without the prior permission of MCCI Corporation
#
# Author:
#	Sivaprakash Veluthambi, MCCI Corporation	June 2020
#
# Revision History:
#   2.01  Mon Jun 18 2020 17:02:00  sveluthambi
#	Module created.
#
##############################################################################*/

/*

Name:	compareDates

Function:
	Google App Script function for comparing the From and To dates

Definition:
	function compareDates(
		argFromDate,
		argToDate
		)

Description:
	This function makes sure that the From Date is not greater than the
	To Date entered in the Get Data window.

Returns:
	Returns Boolean (true if Right & false if Wrong).

*/

function compareDates(argFromDate, argToDate) {
	var fDate = new Date(argFromDate);
	var tDate = new Date(argToDate);
	Logger.log(fDate);
	Logger.log(tDate);
	if (Date.parse(fDate) > Date.parse(tDate)) {
		return false;
	}
    	return true;
}

/*

Name:	convertDateFormat

Function:
	Google App Script function for converting the date formats

Definition:
	function convertDateFormat(dateVal)

Description:
	This function converts the Date format into mm-dd-yyyy.

Returns:
	Returns Boolean (true if Right & false if Wrong).

*/

function convertDateFormat(dateVal) {
        var convertedDate;
        var receivedDate = new Date(dateVal);
        var d = receivedDate.getDate();
        var m = receivedDate.getMonth() + 1;
        var y = receivedDate.getFullYear();

        convertedDate = m + "-" + d + "-" + y;
        return convertedDate;
}
