/*##############################################################################
#
# Module:  main.gs
#
# Function:
#	Google Spreadsheet Add-on that Installs & Initiates the Add-on.
#
# Version:
#	V2.02	Tue Jun 21 2020 11:15:000 sveluthambi	Edit level 2
#
# Copyright notice:
#	This file copyright (C) 2020 by
#
#		MCCI Corporation
#		3520 Krums Corners Road
#		Ithaca, NY  14850
#
#	An unpublished work.  All rights reserved.
#
#	This file is proprietary information, and may not be disclosed or
#	copied without the prior permission of MCCI Corporation
#
# Author:
#	Sivaprakash Veluthambi, MCCI Corporation	June 2020
#
# Revision History:
#   V2.01  Mon Jun 15 2020 17:02:00  sveluthambi
#	Module created.
#
#   2.02  Tue Jun 21 2020 11:15:00  sveluthambi
#	Added extra argument All for Client Looping and common prefix
#
##############################################################################*/

/**
 * @fileoverview File to initiate menus and open respective dialog windows
 * to receive data and plot it in spreadsheet
 */

var docProperty = PropertiesService.getDocumentProperties();

/*

Name:	onInstall

Function:
	Google App Script Install function that Initializes the Add-on on
	Execute

Definition:
	function onInstall(e)

Description:
	This function initializes the required parameters and calls up the
	respective functions that loads the user selected Template Model in the
	spreadsheet.

Returns:
	Nothing.

*/

function onInstall(e) {
	onOpen(e);
	}

/*

Name:	onInstall

Function:
	Google App Script function that Initiates the Add-on and Creates Menu

Definition:
	function onOpen(e)

Description:
	This function initializes the required parameters and calls up the
	respective functions that loads the user selected Template Model in the
	spreadsheet.

Returns:
	Nothing.

*/

function onOpen(e){
	var ui = SpreadsheetApp.getUi();

	ui.createMenu('MCCI')
	.addItem('Manage Connection', 'manageConnection')
	.addItem('Get Data', 'getData')
	.addItem('Refresh', 'refreshSheet')
	.addItem('About', 'about')
	.addToUi();

	docProperty.setProperty('token', '');
	docProperty.setProperty('userStatus', '');
	}

/*

Name:	manageConnection

Function:
	Google App Script function that initiates login dialogue box to
	establish a secure connection to the Server

Definition:
	function manageConnection()

Description:
	This function initializes the required parameters and calls up the
	respective functions that loads the user selected Template Model in the
	spreadsheet.

Returns:
	Nothing.

*/

function manageConnection(){
	var html = HtmlService.createHtmlOutputFromFile('login')
	.setSandboxMode(HtmlService.SandboxMode.IFRAME);

	html.setWidth(400);
	html.setHeight(250);

	SpreadsheetApp.getUi().showModalDialog(html, "Login");
	}

/*

Name:	include

Function:
	Google App Script function that files using filename

Definition:
	function include(filename)

Description:
	This function initializes the required parameters and calls up the
	respective functions that loads the user selected Template Model in the
	spreadsheet.

Returns:
	Nothing.

*/

function include(filename) {

	return HtmlService.createHtmlOutputFromFile(filename)
	.setSandboxMode(HtmlService.SandboxMode.IFRAME)
	.getContent();
	}


/*

Name:	loginRequest

Function:
	Google App Script function to process the login details and provide a
	secure connection files using the credentials filed in it

Definition:
	function loginRequest(
		requrl,
		username,
		password
		)

Description:
	This function initializes the required parameters and calls up the
	respective functions that loads the user selected Template Model in the
	spreadsheet.

Returns:
	Nothing.

*/
function loginRequest(
		requrl,
		username,
		password
		)
	{
	docProperty.setProperty('token', '');
	docProperty.setProperty('userStatus', '');
	var ui = SpreadsheetApp.getUi();
	var url = 'https://'
			+ requrl
			+ '?uname='
			+ username
			+ '&pwd='
			+ password;
	var methodType = 'post';
	var response;

	response = sendRequest(url, methodType);

	if(response.clients && response.token) {
		var clients = response;
		var token = response.token;
		delete clients.token;
		docProperty.setProperty('token', token);
		docProperty.setProperty('userStatus', 'admin');
		docProperty.setProperty('clientList', JSON.stringify(clients));
		alertMsg("Connection Estabished");
		}
	else if(response.client && response.token) {
		var client = response;
		var token = response.token;
		delete client.sites;
		delete client.token;
		docProperty.setProperty('token', token);
		docProperty.setProperty('userStatus', 'client');
		docProperty.setProperty('client', JSON.stringify(client));
		alertMsg("Connection Estabished");
		}
	else {
		errorMsg("Connection failed");
		return false;
		}
	}

/*

Name:	getData

Function:
	Google App Script function to Opens get data dialog box and send
	request to server for receiving data

Definition:
	function getData()

Description:
	This function initializes the required parameters and calls up the
	respective functions that loads the user selected Template Model in the
	spreadsheet.

Returns:
	Nothing.

*/

function getData(){
	var userStatus = docProperty.getProperty('userStatus');
	var token = docProperty.getProperty('token');
	var ui = SpreadsheetApp.getUi();

	if(token && userStatus == 'admin') {
		adminClients = docProperty.getProperty('clientList');
		clientInfo = JSON.parse(adminClients);
		clientInfo.userStatus = userStatus;
		}
	else if(token && userStatus == 'client') {
		userClient = docProperty.getProperty('client');
		clientInfo = JSON.parse(userClient);
		clientInfo.userStatus = userStatus;
		}
	else {
		errorMsg("Can't recognize user.\n Please login.");
		return false;
		}

	var template = HtmlService.createTemplateFromFile('get-data');
	template.data = JSON.stringify(clientInfo);
	var html = template.evaluate();
	html.setWidth(380);
	html.setHeight(400);
	ui.showModalDialog(html, 'Get Data');
	}

/*

Name:	queryData

Function:
	Google App Script function to collect data from the Get Data
	dialogue box and share it to template loading functions

Definition:
	function queryData(frmGetData)

Description:
	This function initializes the required parameters and calls up the
	respective functions that loads the user selected Template Model in the
	spreadsheet.

Returns:
	Nothing.

*/

function queryData(frmGetData) {
	var ui = SpreadsheetApp.getUi();
	var js = " \
		<script> \
		google.script.host.close(); \
		</script> \
		";

	var html = HtmlService.createHtmlOutput(js)
	.setHeight(10)
	.setWidth(300);
	ui.showModalDialog(html, 'Now loading the template...');

	var queryData = JSON.parse(frmGetData);

	//var client = queryData.client;
	var client;

	if(queryData.client.indexOf('All') != -1) {
		let allClients = docProperty.getProperty('clientList');
		let pAllClients = JSON.parse(allClients);
		client = pAllClients.clients;
		}
	else {
		client = queryData.client;
	}

	var startDate = queryData.startDate;
	var toDate = queryData.toDate;
	var aggregator = queryData.aggregator.toLowerCase();
	var template = queryData.template;
	var refCount = queryData.refLineCount;

	var verifyDate = compareDates(startDate, toDate);

	if(verifyDate == false) {
		alertMsg('From Date must be lower than To Date');
		getData();
		return false;
		}

	var formattedStartDate = convertDateFormat(startDate);
	var formattedToDate = convertDateFormat(toDate);
	var refCountNum = parseInt(refCount);

	weradiate_DT_initClient(
		formattedStartDate,
		formattedToDate,
		aggregator,
		template,
		refCountNum
		);

	weradiate_DT_loadTemplate(client);
	}

/*

Name:	refreshSheet

Function:
	Google App Script function to Refresh the Spreadsheet

Definition:
	function refreshSheet()

Description:
	This function clears/refreshes the spreadsheet and provides an alert
	message before clearing the spreadsheet to save a copy.

Returns:
	Nothing.

*/

function refreshSheet(){
	try {
		var ui = SpreadsheetApp.getUi();
		var response = ui.alert('Do you want to save a copy before clearing the sheet(s)?'
				    , ui.ButtonSet.YES_NO);
		if (response == ui.Button.YES) {
			ui.alert('Use the Import or Download option under File Tab');
			return false;
			}
		else if (response == ui.Button.NO) {
			//do nothing continue the process
			}
		else {
			return false;
			}

		var ss = SpreadsheetApp.getActiveSpreadsheet();
		ss.insertSheet();

		var newSheetName = ss.getSheetName();
		var allSheets = ss.getSheets();

		for (var i in allSheets) {
			if(allSheets[i].getName() != newSheetName) {
				ss.deleteSheet(allSheets[i]);
				}
			}
		}
	catch(err) {
		alertMsg('Can\'t refresh sheet');
		logMsg(err);
		}
	}


/*

Name:	about

Function:
	Google App Script function to display About Dialogue Box

Definition:
	function about()

Description:
	This function clears/refreshes the spreadsheet and provides an alert
	message before clearing the spreadsheet to save a copy.

Returns:
	Nothing.

*/

function about(){
	var html = HtmlService.createHtmlOutputFromFile('about')
	.setSandboxMode(HtmlService.SandboxMode.IFRAME);

	html.setWidth(280);
	html.setHeight(320);

	SpreadsheetApp.getUi().showModalDialog(html, "About");
	}
