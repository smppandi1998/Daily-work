/*##############################################################################
#
# Module:  template_model2.gs
#
# Function:
#	Google Spreadsheet Add-on that populates the data from server into spreadsheet.
#
# Version:
#	V2.02	Mon Aug 03 2020 12:34:00 revathy	Edit level 2
#
# Copyright notice:
#	This file copyright (C) 2020 by
#
#		MCCI Corporation
#		3520 Krums Corners Road
#		Ithaca, NY  14850
#
#	An unpublished work.  All rights reserved.
#
#	This file is proprietary information, and may not be disclosed or
#	copied without the prior permission of MCCI Corporation
#
# Author:
#	Revathy Gajendran, MCCI Corporation	June 2020
#
# Revision History:
#   2.01  Mon Jun 15 2020 17:02:00  revathy
#	Module created.
#   2.02  Mon Aug 03 2020 12:34:00  revathy
#	Common prefix and reference column position change for color coding
#
##############################################################################*/

/*
Name:	weradiate_DT_init_template2

Function:
	Google App Script function to init template model 2

Definition:
	function weradiate_DT_init_template2(
		weradiate_DT_hClient,
		site,
		spreadsheet,
	book
		)

Description:
	This function initiates information for data filling in the spreadsheet
	w.r.t the Model 2 template

Returns:
	Nothing.
*/

function weradiate_DT_init_template2(
	weradiate_DT_hClient,
	weradiate_DT_site,
	spreadsheet,
	book
	)
	{
	var client_name = weradiate_DT_hClient.client;
	var title = client_name + ' Template (Model 2)';
	var main_sheet_name = weradiate_DT_site  + " - Cumulative Data" ;
	var title_cell = 'D2';
	var datacolumn = 0;

	spreadsheet.setName(main_sheet_name);
	start_data_row = 5;

	fromDate = weradiate_DT_getFromDate(weradiate_DT_hClient);
	toDate = weradiate_DT_getToDate(weradiate_DT_hClient);
	tFromDate = weradiate_DT_formatDate(fromDate);
	tToDate = weradiate_DT_formatDate(toDate);

	var startdate = tFromDate;
	var enddate = tToDate;

	var day_heading_cell = 'B5';
	var date_heading_cell = 'C5';
	var data_heading_cell = 'E5';
	var starting_data_row = 6;
	var day_fill_column = 2;

	weradiate_DT_TitleCard(spreadsheet,title,title_cell);
	spreadsheet.getRange(day_heading_cell).activate();
	spreadsheet.getCurrentCell().setValue('Day');
	spreadsheet.getActiveRangeList().setHorizontalAlignment('center');
	spreadsheet.getRange(date_heading_cell).activate();
	spreadsheet.getCurrentCell().setValue('Date');
	spreadsheet.getActiveRangeList().setHorizontalAlignment('center');
	spreadsheet.getRange(data_heading_cell).activate();
	spreadsheet.getRange(day_heading_cell + ':' + data_heading_cell).activate();
	spreadsheet.getActiveRangeList().setBorder(true, true, true, true, true, true, '#000000', SpreadsheetApp.BorderStyle.SOLID)
	.setFontSize(10);

	/*generating an array of list of dates for specifed range
	to compare with json response*/
	HeaderData = weradiate_DT_generate_data(startdate, enddate);
	const fnGet2D = function(v) {
		return  [v[0], v[1]] ;
		};
	const fnGet1D = function(v) {
		return  v[2] ;
		};
	dateFilling_start_row = 6;
	dateFilling_start_column = 2;
	dateFilling_last_column = 2;
	spreadsheet.getRange(dateFilling_start_row, dateFilling_start_column, HeaderData.length, dateFilling_last_column)
	.setHorizontalAlignment('center').setValues(HeaderData.map(fnGet2D))
	.setBorder(true, true, true, true, true, true, '#000000', SpreadsheetApp.BorderStyle.SOLID);
	//reference_column = dateFilling_start_column + dateFilling_last_column

	date_heading = HeaderData.map(fnGet1D);
	Logger.log("date_heading");
	Logger.log(date_heading);
	datacolumn = 0;
	Logger.log(weradiate_DT_site);
	weradiate_DT_piles = weradiate_DT_getAllPilesOfaSite(weradiate_DT_hClient,weradiate_DT_site);
	Logger.log(weradiate_DT_piles);

	var chart_sheet_index = 1;
	var reference_row = 5;
	var reference_column = 4;

	spreadsheet.insertColumns(reference_column);
	var refLineValue = weradiate_DT_getRefLineCount(weradiate_DT_hClient);
var ref1 = spreadsheet.getRange(reference_row, reference_column).getA1Notation();
	var ref2 = spreadsheet.getRange(reference_row+HeaderData.length, reference_column).getA1Notation();
	reference_range = ref1+':'+ref2;
	spreadsheet.getRange(reference_range).setValue(refLineValue);
	spreadsheet.hideColumns(reference_column);
	for ( var pile = 0; pile < weradiate_DT_piles.length; pile++)
		{
		Logger.log(weradiate_DT_site,weradiate_DT_piles[pile]);
		weradiate_DT_locations = weradiate_DT_getAllLocationOfaPile(weradiate_DT_hClient, weradiate_DT_site, weradiate_DT_piles[pile]);
		Logger.log(weradiate_DT_site,weradiate_DT_piles[pile],weradiate_DT_locations);
		for (var location=0; location < weradiate_DT_locations.length; location++)
			{
			Logger.log(weradiate_DT_site,weradiate_DT_piles[pile],weradiate_DT_locations[location]);
			Logger.log(main_sheet_name);
			Logger.log(spreadsheet.getSheetName());
			spreadsheet.getRange(data_heading_cell).offset(0, datacolumn).activate();
			Logger.log(weradiate_DT_hClient, tFromDate, tToDate, weradiate_DT_site, weradiate_DT_piles[pile], weradiate_DT_locations[location],
			spreadsheet,spreadsheet.getRange(data_heading_cell).offset(0, datacolumn).getColumn(),
			date_heading);
			weradiate_DT_column_datafill(
				weradiate_DT_hClient,
				tFromDate,
				tToDate,
				weradiate_DT_site,
				weradiate_DT_piles[pile],
				weradiate_DT_locations[location],
				spreadsheet,
				spreadsheet.getRange(data_heading_cell).offset(0, datacolumn).getColumn(),
			    date_heading);
			weradiate_DT_plot_chart_template2(
				HeaderData.length,
				spreadsheet.getRange(data_heading_cell).offset(0,
				datacolumn).getColumn(),
				(weradiate_DT_site+'|'+weradiate_DT_piles[pile]+'|'+weradiate_DT_locations[location] + " Chart"),
				spreadsheet,
				weradiate_DT_site,
				book,
				chart_sheet_index
				);
			chart_sheet_index++;
			datacolumn++;
			}
		}

	weradiate_DT_plot_sites(
		HeaderData.length,
		spreadsheet.getRange(data_heading_cell).offset(0,
		datacolumn).getColumn(),
		weradiate_DT_site+'-Cumulative Chart',
		spreadsheet,
		weradiate_DT_site,
		book,
		chart_sheet_index
		);
	};

/*
Name:	weradiate_DT_plot_sites

Function:
	Google App Script function to provide Chart representation for Model 2

Definition:
	function weradiate_DT_plot_sites(
			length,
			no_of_columns,
			sheet_name,
			spreadsheet,
			weradiate_DT_site,
	    book,
	    chart_sheet_index
			)

Description:
	This function plots the cumulative representation for the data in a separate sheet

Returns:
	Nothing.
*/

function weradiate_DT_plot_sites(
	length,
	no_of_columns,
	sheet_name,
	spreadsheet,
	weradiate_DT_site,
	book,
	chart_sheet_index
	)

	{
	var name = sheet_name
	var start_row_xaxis = 5
	var start_column_xaxis = 3
	var reference_row = 5
	var reference_column = 4
	var chart_flag = 1;
	var chart_sheet = book.getSheetByName(name);

	if (chart_sheet != null)
		{
		book.deleteSheet(chart_sheet);
		}

	chart_sheet = book.insertSheet(chart_sheet_index).setName(name);
	var xrange1 = spreadsheet.getRange(start_row_xaxis, start_column_xaxis).getA1Notation();
	var yrange2 = spreadsheet.getRange(start_row_xaxis + length, start_column_xaxis+no_of_columns+1).getA1Notation();
	range = xrange1+':'+yrange2

	var ref1 = spreadsheet.getRange(reference_row, reference_column).getA1Notation();
	var ref2 = spreadsheet.getRange(reference_row+length, reference_column).getA1Notation();
	reference_range = ref1+':'+ref2;
	Logger.log(reference_range);

	chart_position = 5;
	reference_series_index = no_of_columns;
	weradiate_DT_createEmbeddedLineChart_(
		chart_sheet,
		spreadsheet,
		chart_flag,
		range,
		chart_position,
		reference_range,
		reference_series_index
		);
	}

/*

Name:	weradiate_DT_plot_chart_template2

Function:
	Google App Script function to represent the chart for template model 2

Definition:
	function plot_chart_template2(
		weradiate_DT_hClient,
		length,
		sheet_name,
		spreadsheet,
		site,
	book,
	chart_sheet_index
		)

Description:
	This function is called to plot chart for the each sensor in the
 	spreadsheet.

Returns:
	Nothing.

*/

function weradiate_DT_plot_chart_template2(
	length,
	column,
	sheet_name,
	spreadsheet,
	weradiate_DT_site,
	book,
	chart_sheet_index
	)
	{
	var name = sheet_name
	var reference_row = 5
	var reference_column = 4
	var start_row = 5
	var start_column = 3
	var chart_flag = 0;
	var chart_sheet = book.getSheetByName(name);

	if (chart_sheet != null)
		{
		book.deleteSheet(chart_sheet);
		}
	chart_sheet = book.insertSheet(chart_sheet_index).setName(name);

	var xrange1 = spreadsheet.getRange(start_row, start_column).getA1Notation();
	var xrange2 = spreadsheet.getRange(start_row + length, start_column).getA1Notation();
	var yrange1 = spreadsheet.getRange(start_row, column).getA1Notation();
	var yrange2 = spreadsheet.getRange(start_row + length, column).getA1Notation();
	xrange = xrange1+':'+xrange2
	yrange = yrange1+':'+yrange2
	Logger.log(xrange + yrange);

	var ref1 = spreadsheet.getRange(reference_row, reference_column).getA1Notation();
	var ref2 = spreadsheet.getRange(reference_row+length, reference_column).getA1Notation();
	reference_range = ref1+':'+ref2;
	Logger.log(reference_range);

	weradiate_DT_createEmbeddedLineChart_(
		chart_sheet,
		spreadsheet,
		chart_flag,
		xrange,
		yrange,
		reference_range
		);
	}
