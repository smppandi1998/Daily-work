/*##############################################################################
#
# Module:  template_utility_functions.gs
#
# Function:
#	Google Spreadsheet Add-on utility functions that populates the data from server into spreadsheet.
#
# Version:
#	V2.02  Tue Jul 14 2020 12:45:00 revathy	Edit level 2
#
# Copyright notice:
#	This file copyright (C) 2020 by
#
#		MCCI Corporation
#		3520 Krums Corners Road
#		Ithaca, NY  14850
#
#	An unpublished work.  All rights reserved.
#
#	This file is proprietary information, and may not be disclosed or
#	copied without the prior permission of MCCI Corporation
#
# Author:
#	Revathy Gajendran, MCCI Corporation	June 2020
#
# Revision History:
#   2.01  Mon Jun 18 2020 17:02:00  revathy
#	Module created.
#
#   2.02  Tue Jul 14 2020 12:45:00  revathy
#	Added Common Prefix for func's and fixed cell borders.
#
##############################################################################*/

/*

Name:	weradiate_DT_FillSensorData

Function:
	Function to fill data in specified column in spreadsheet

Definition:
	function weradiate_DT_FillSensorData(
		spreadSheet,
		start_row,
		start_col,
		query_result,
		date_heading
		)
Description:
	This function fills the data in the spreadsheet by receiving the column number
	as parameter

Returns:
	Nothing.

*/
function weradiate_DT_FillSensorData(
	spreadSheet,
	start_row,
	start_col,
	query_result,
	date_heading
	)
	{
	var sensor_data = {};
	var OutputRow = [];

	/* Traverse all the sensor data and make an enrty to sensorData with date as index */
	for (i in query_result[0].Values)
		{
		sensor_data[query_result[0].Values[i].slice(0,1)] =
		query_result[0].Values[i].slice(1,2);
		}
	/* Loop through each date in date_heading and make entries of data present
	sensor in the array, otherwise enter empty value */

	for(var date in date_heading)
		{
		if (sensor_data[date_heading[date]])
			{
			OutputRow.push(sensor_data[date_heading[date]]);
			}
		else
			{
			OutputRow.push([""]);
			}
		}

	Logger.log(OutputRow.length);
	Logger.log(OutputRow);
	// Add the data including heading
	spreadSheet.getRange(start_row, start_col, OutputRow.length, OutputRow[0].length)
		.setValues(OutputRow).setHorizontalAlignment('center').setNumberFormat("0.00")
		.setBorder(true, true, true, true, true, true, '#000000', SpreadsheetApp.BorderStyle.SOLID);
	spreadSheet.autoResizeColumn(start_col);
	}

/*

Name:	weradiate_DT_column_datafill

Function:
	Function to receive response data for a location and pass to fillsensor data

Definition:
	function weradiate_DT_column_datafill(
		weradiate_DT_hClient,
		tFromDate,
		tToDate,
		site,
		pile,
		location,
		sheet,
		column,
		dateheading
		)

Description:
	This function fetches the data of location and pass it to filling function

Returns:
	Nothing.

*/
function weradiate_DT_column_datafill(
	weradiate_DT_hClient,
	tFromDate,
	tToDate,
	site,
	pile,
	location,
	sheet,
	column,
	dateheading
	)
	{
	var column_name = site + ' | ' + pile + ' | '+ location;
	var aggregator = weradiate_DT_getAggregator(weradiate_DT_hClient);
	column_heading_row = 5;
	start_row = 6;

	sheet.getRange(column_heading_row, column).setValue(column_name)
		.setBorder(true, true, true, true, true, true, '#000000', SpreadsheetApp.BorderStyle.SOLID);

	var response_data = weradiate_DT_getDataOfaLocation(weradiate_DT_hClient, site, pile, location);

	if(response_data.message)
		{
		sheet.getRange(start_row, column, dateheading.length)
			.setHorizontalAlignment('center').setNumberFormat("0.00")
			.setBorder(true, true, true, true, true, true, '#000000', SpreadsheetApp.BorderStyle.SOLID);
		sheet.autoResizeColumn(column);
		return;	/* If the response comes as message (apart from "result") return */
		}

	var parse_result = response_data.results;
	weradiate_DT_FillSensorData(sheet, start_row, column, parse_result, dateheading);
	}
/*

Name:	weradiate_DT_generate_data

Function:
	Function to generate normal date, date with UTC timeformat, Day number

Definition:
	function weradiate_DT_generate_data(
		startDateStr,
		endDateStr
		)

Description:
	This function generate a 3D array with normal date format,
	date with UTC string and Day number

Returns:
	Returns 3D array as HeaderData.

*/

function weradiate_DT_generate_data(
	startDateStr,
	endDateStr
	)
	{
	Logger.log(startDateStr, endDateStr);
	var HeaderData = [];
	var DayCount = 1;
	var dateIndex  = new Date(startDateStr + ' 00:00:00Z');
	var endDate  = new Date(endDateStr + ' 00:00:00Z');

	while (dateIndex.valueOf() <= endDate.valueOf())
		{
		var dateString = dateIndex.toISOString().slice(0,10);
		var dateStringTZ = dateString +"T00:00:00Z" ;

		HeaderData.push([DayCount, dateString, dateStringTZ]);
		++DayCount;
		dateIndex.setDate(dateIndex.getDate() + 1);
		}
	return HeaderData;
	}

/*
Name:	weradiate_DT_formatDate

Function:
	Function to format date

Definition:
	function weradiate_DT_formatDate(dateVal)

Description:
	This function returns a formatted date when called with the date string.

Returns:
	Returns fDate as String.

*/
function weradiate_DT_formatDate(dateVal)
	{
	var dateVal = new Date(dateVal);
	d = dateVal.getDate();
	m = dateVal.getMonth() + 1;
	y = dateVal.getFullYear();
	fDate = y + "-" + m + "-" + d;

	return fDate;
	}

/*

Name:	weradiate_DT_TitleCard

Function:
	Function to set formatting style Cell for the Title

Definition:
	function weradiate_DT_TitleCard (spreadsheet, title, title_cell)

Description:
	This function sets the formatting style for a Cell in the spreadsheet
	for the Title.

Returns:
	Nothing.

*/
function weradiate_DT_TitleCard (spreadsheet, title, title_cell)
	{
	const boldStyle = SpreadsheetApp.newTextStyle()
	.setFontSize(14)
	.setBold(true)
	.build();

	const value = SpreadsheetApp.newRichTextValue()
	.setText(title)
	.setTextStyle(0, title.length, boldStyle)
	.build();

	spreadsheet.getRange(title_cell).setRichTextValue(value);
	}
